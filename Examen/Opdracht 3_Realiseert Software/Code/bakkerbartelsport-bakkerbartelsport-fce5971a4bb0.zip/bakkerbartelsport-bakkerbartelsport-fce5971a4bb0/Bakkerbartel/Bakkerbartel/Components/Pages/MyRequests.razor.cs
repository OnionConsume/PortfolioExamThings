using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bakkerbartel.Entities;
using Blazorise;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace Bakkerbartel.Components.Pages;

// Deze code achter de pagina regelt de aanvragen van één medewerker.
public partial class MyRequests : ComponentBase
{
    private List<VacationRequest> EmployeeRequests { get; set; } = [];
    private IReadOnlyList<CalendarAppointment> Appointments { get; set; } = [];
    private IReadOnlyList<Employee> Employees { get; set; } = [];
    private DateTime CurrentDate { get; set; } = DateTime.Today;
    private DateTime NewStartDateTime { get; set; } = DateTime.Today.AddDays(1);
    private DateTime NewEndDateTime { get; set; } = DateTime.Today.AddDays(2);
    private string NewReason { get; set; } = string.Empty;

    private IReadOnlyList<DateTime> VisibleDays => Enumerable.Range(0, 7)
        .Select(offset => GetStartOfWeek(CurrentDate).AddDays(offset))
        .ToList();

    private IReadOnlyList<EmployeeCalendarRow> EmployeeRows => Employees
        .Select(employee => new EmployeeCalendarRow(employee.FullName, employee.Role.ToDisplayName()))
        .OrderBy(row => row.Name)
        .ToList();

    // Laadt de gegevens van de medewerker als de pagina opent.
    protected override async Task OnInitializedAsync()
    {
        await LoadRequestsAsync();
    }

    // Haalt aanvragen, werknemers en kalenderafspraken op.
    private async Task LoadRequestsAsync()
    {
        if (UserContextService.CurrentEmployeeId is int employeeId)
        {
            try
            {
                Employees = await UserContextService.GetEmployeesAsync();
                EmployeeRequests = (await VacationRequestService.GetForEmployeeAsync(employeeId)).ToList();
                Appointments = await CalendarService.GetApprovedAppointmentsAsync();
                CurrentDate = Appointments.Count > 0
                    ? Appointments.Min(appointment => appointment.Start)
                    : DateTime.Today;
            }
            catch (UnauthorizedAccessException)
            {
                Employees = [];
                EmployeeRequests = [];
                Appointments = [];
            }
        }
        else
        {
            Employees = [];
            EmployeeRequests = [];
            Appointments = [];
        }
    }

    // Verstuurt een nieuwe vakantieaanvraag.
    private async Task SubmitRequestAsync()
    {
        if (UserContextService.CurrentEmployeeId is not int employeeId)
        {
            return;
        }

        var newStartDate = DateOnly.FromDateTime(NewStartDateTime.Date);
        var newEndDate = DateOnly.FromDateTime(NewEndDateTime.Date);

        if (newEndDate < newStartDate || string.IsNullOrWhiteSpace(NewReason))
        {
            NotificationService.Notify(new NotificationMessage
            {
                Severity = NotificationSeverity.Warning,
                Summary = "Aanvraag onvolledig",
                Detail = "Vul geldige data en een reden in.",
                Duration = 3000
            });
            return;
        }

        if (newStartDate < DateOnly.FromDateTime(DateTime.Today))
        {
            NotificationService.Notify(new NotificationMessage
            {
                Severity = NotificationSeverity.Warning,
                Summary = "Aanvraag onjuist",
                Detail = "De startdatum mag niet in het verleden liggen.",
                Duration = 3000
            });
            return;
        }

        try
        {
            await VacationRequestService.CreateAsync(employeeId, newStartDate, newEndDate, NewReason);
        }
        catch (Exception exception) when (exception is InvalidOperationException || exception is UnauthorizedAccessException)
        {
            NotificationService.Notify(new NotificationMessage
            {
                Severity = NotificationSeverity.Warning,
                Summary = "Aanvraag niet opgeslagen",
                Detail = exception.Message,
                Duration = 3500
            });
            return;
        }

        NotificationService.Notify(new NotificationMessage
        {
            Severity = NotificationSeverity.Success,
            Summary = "Aanvraag ingediend",
            Detail = "Je vakantieaanvraag is opgeslagen als InBehandeling.",
            Duration = 3000
        });

        NewStartDateTime = DateTime.Today.AddDays(1);
        NewEndDateTime = DateTime.Today.AddDays(2);
        NewReason = string.Empty;
        await LoadRequestsAsync();
    }

    // Haalt de afspraken op voor één werknemer op één dag op.
    private IReadOnlyList<CalendarAppointment> GetAppointmentsForCell(string employeeName, DateTime day)
    {
        var date = day.Date;

        return Appointments
            .Where(appointment =>
                appointment.EmployeeName == employeeName &&
                appointment.Start.Date <= date &&
                appointment.End.Date >= date)
            .OrderBy(appointment => appointment.Start)
            .ToList();
    }

    // Verplaatst het weekoverzicht.
    private void MoveWeek(int dayOffset)
    {
        CurrentDate = CurrentDate.AddDays(dayOffset);
    }

    // Zet het weekoverzicht terug naar deze week.
    private void ResetToCurrentWeek()
    {
        CurrentDate = DateTime.Today;
    }

    // Geeft de datumrange van de zichtbare week terug.
    private string GetWeekRangeLabel()
    {
        var start = GetStartOfWeek(CurrentDate);
        var end = start.AddDays(6);

        return $"{start:dd MMM} - {end:dd MMM yyyy}";
    }

    // Berekent de maandag van de week.
    private static DateTime GetStartOfWeek(DateTime date)
    {
        var diff = ((int)date.DayOfWeek + 6) % 7;
        return date.Date.AddDays(-diff);
    }

    // Geeft de CSS-class terug die bij de afspraakstatus hoort.
    private static string GetEntryClass(CalendarAppointment appointment) => appointment.TypeLabel switch
    {
        "Goedgekeurd" => "is-approved",
        "Afgekeurd" => "is-rejected",
        _ => "is-pending"
    };

    // Kiest de badgekleur op basis van de aanvraagstatus.
    private static Color GetStatusColor(VacationRequestStatus status) => status switch
    {
        VacationRequestStatus.Pending => Color.Warning,
        VacationRequestStatus.Approved => Color.Success,
        VacationRequestStatus.Rejected => Color.Danger,
        _ => Color.Secondary
    };

    // Zet de status om naar een leesbaar label.
    private static string GetStatusLabel(VacationRequestStatus status) => status switch
    {
        VacationRequestStatus.Pending => "InBehandeling",
        VacationRequestStatus.Approved => "Goedgekeurd",
        VacationRequestStatus.Rejected => "Afgekeurd",
        _ => "Onbekend"
    };

    // Deze record bewaart alleen de gegevens die in de kalendertabel nodig zijn.
    private sealed record EmployeeCalendarRow(string Name, string Role);
}
