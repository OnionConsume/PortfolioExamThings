using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bakkerbartel.Entities;
using Bakkerbartel.Services;
using Blazorise;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace Bakkerbartel.Components.Pages;

// Deze code achter de pagina regelt het kalenderoverzicht en de beoordeling van aanvragen.
public partial class Calendar : ComponentBase
{
    private DateTime CurrentDate { get; set; } = DateTime.Today;
    private IReadOnlyList<CalendarAppointment> Appointments { get; set; } = [];
    private IReadOnlyList<VacationRequest> AllRequests { get; set; } = [];
    private IReadOnlyList<VacationRequest> PendingRequests { get; set; } = [];
    private IReadOnlyList<Employee> Employees { get; set; } = [];
    private CalendarAppointment? SelectedAppointment { get; set; }
    private VacationRequest? SelectedRequest { get; set; }
    private VacationRequest? SelectedRequestForNote { get; set; }
    private VacationRequest? ApprovalWarningRequest { get; set; }
    private StaffingValidationResult? ApprovalWarningResult { get; set; }
    private string PendingEmployeeSearchTerm { get; set; } = string.Empty;
    private string NoteDraft { get; set; } = string.Empty;
    private ReviewRequestPeriod PendingRequestPeriodFilter { get; set; } = ReviewRequestPeriod.All;
    private bool ShowRejectedAppointments { get; set; }
    private bool IsNoteModalOpen { get; set; }
    private bool IsApprovalWarningModalOpen { get; set; }

    // Laadt alle gegevens die nodig zijn voor de kalender.
    protected override async Task OnInitializedAsync()
    {
        await LoadDataAsync();
    }

    private IReadOnlyList<DateTime> VisibleDays => Enumerable.Range(0, 7)
        .Select(offset => GetStartOfWeek(CurrentDate).AddDays(offset))
        .ToList();

    private IReadOnlyList<VacationRequest> FilteredPendingRequests => PendingRequests
        .Where(MatchesPendingEmployeeSearch)
        .Where(MatchesPendingPeriodFilter)
        .ToList();

    private IReadOnlyList<EmployeeCalendarRow> EmployeeRows => Employees
        .Select(employee => new EmployeeCalendarRow(
            employee.FullName,
            employee.Role.ToDisplayName()))
        .OrderBy(row => row.Name)
        .ToList();

    // Selecteert een afspraak en zoekt de bijbehorende aanvraag erbij.
    private void SelectAppointment(CalendarAppointment appointment)
    {
        SelectedAppointment = appointment;
        if (SelectedAppointment is null)
        {
            SelectedRequest = null;
            return;
        }

        SelectedRequest = AllRequests.FirstOrDefault(request => request.Id == SelectedAppointment.Id);
    }

    // Haalt de afspraken op voor één werknemer op één dag op.
    private IReadOnlyList<CalendarAppointment> GetAppointmentsForCell(string employeeName, DateTime day)
    {
        var date = day.Date;

        return Appointments
            .Where(appointment =>
                appointment.EmployeeName == employeeName &&
                appointment.Start.Date <= date &&
                appointment.End.Date >= date)
            .OrderBy(appointment => appointment.Start)
            .ToList();
    }

    // Verplaatst de kalender een week terug of vooruit.
    private void MoveWeek(int dayOffset)
    {
        CurrentDate = CurrentDate.AddDays(dayOffset);
    }

    // Zet de kalender terug naar de huidige week.
    private void ResetToCurrentWeek()
    {
        CurrentDate = DateTime.Today;
    }

    // Wisselt of afgewezen aanvragen zichtbaar zijn in de kalender.
    private async Task ToggleRejectedAppointmentsAsync()
    {
        ShowRejectedAppointments = !ShowRejectedAppointments;
        await LoadDataAsync();
    }

    // Geeft de labeltekst van de huidige week terug.
    private string GetWeekRangeLabel()
    {
        var start = GetStartOfWeek(CurrentDate);
        var end = start.AddDays(6);

        return $"{start:dd MMM} - {end:dd MMM yyyy}";
    }

    // Beoordeelt een aanvraag en toont eventueel roosterwaarschuwingen.
    private async Task ReviewAsync(VacationRequest request, VacationRequestStatus status, bool ignoreWarnings = false)
    {
        if (status == VacationRequestStatus.Approved && !ignoreWarnings)
        {
            var validationResult = await StaffingService.ValidateVacationRequestApprovalAsync(request);
            if (validationResult.HasWarnings)
            {
                ApprovalWarningRequest = request;
                ApprovalWarningResult = validationResult;
                IsApprovalWarningModalOpen = true;
                return;
            }
        }

        try
        {
            await VacationRequestService.ReviewAsync(request.Id, status, request.AdminNote, ignoreWarnings);
        }
        catch (Exception exception) when (exception is InvalidOperationException || exception is UnauthorizedAccessException)
        {
            NotificationService.Notify(new NotificationMessage
            {
                Severity = NotificationSeverity.Warning,
                Summary = "Beoordeling niet opgeslagen",
                Detail = exception.Message,
                Duration = 3500
            });
            return;
        }

        NotificationService.Notify(new NotificationMessage
        {
            Severity = status == VacationRequestStatus.Approved ? NotificationSeverity.Success : NotificationSeverity.Warning,
            Summary = status == VacationRequestStatus.Approved ? "Aanvraag goedgekeurd" : "Aanvraag afgewezen",
            Detail = $"{request.EmployeeName} is bijgewerkt naar {GetStatusLabel(status).ToLowerInvariant()}.",
            Duration = 3500
        });

        await LoadDataAsync();
        SelectedRequest = AllRequests.FirstOrDefault(item => item.Id == request.Id);
        await CloseApprovalWarningModal();
    }

    // Laadt alleen de openstaande aanvragen voor de beheerder.
    private async Task LoadPendingRequestsAsync()
    {
        PendingRequests = UserContextService.IsAdmin
            ? await VacationRequestService.GetPendingAsync()
            : [];
    }

    // Opent het venster om een beheernotitie te wijzigen.
    private void OpenNoteModal(VacationRequest request)
    {
        SelectedRequestForNote = request;
        NoteDraft = request.AdminNote;
        IsNoteModalOpen = true;
    }

    // Sluit het notitievenster.
    private Task CloseNoteModal()
    {
        IsNoteModalOpen = false;
        SelectedRequestForNote = null;
        NoteDraft = string.Empty;
        return Task.CompletedTask;
    }

    // Sluit het venster met roosterwaarschuwingen.
    private Task CloseApprovalWarningModal()
    {
        IsApprovalWarningModalOpen = false;
        ApprovalWarningRequest = null;
        ApprovalWarningResult = null;
        return Task.CompletedTask;
    }

    // Keurt een aanvraag toch goed ondanks waarschuwingen.
    private async Task ConfirmApprovalDespiteWarningsAsync()
    {
        if (ApprovalWarningRequest is null)
        {
            return;
        }

        await ReviewAsync(ApprovalWarningRequest, VacationRequestStatus.Approved, true);
    }

    // Slaat de notitie van de beheerder op.
    private async Task SaveNoteAsync()
    {
        if (SelectedRequestForNote is null)
        {
            return;
        }

        var selectedRequestId = SelectedRequestForNote.Id;
        var selectedEmployeeName = SelectedRequestForNote.EmployeeName;

        try
        {
            await VacationRequestService.SaveAdminNoteAsync(selectedRequestId, NoteDraft);
        }
        catch (UnauthorizedAccessException exception)
        {
            NotificationService.Notify(new NotificationMessage
            {
                Severity = NotificationSeverity.Warning,
                Summary = "Notitie niet opgeslagen",
                Detail = exception.Message,
                Duration = 3500
            });
            return;
        }

        await CloseNoteModal();
        NotificationService.Notify(new NotificationMessage
        {
            Severity = NotificationSeverity.Info,
            Summary = "Notitie opgeslagen",
            Detail = $"De notitie voor {selectedEmployeeName} is opgeslagen.",
            Duration = 2500
        });

        await LoadDataAsync();
        SelectedRequest = AllRequests.FirstOrDefault(item => item.Id == selectedRequestId);
    }

    // Laadt alle data voor de pagina opnieuw.
    private async Task LoadDataAsync()
    {
        Employees = await UserContextService.GetEmployeesAsync();

        if (UserContextService.IsAdmin)
        {
            Appointments = await CalendarService.GetAppointmentsAsync(ShowRejectedAppointments);
            AllRequests = await VacationRequestService.GetAllAsync();
        }
        else if (UserContextService.CurrentEmployeeId is int)
        {
            Appointments = await CalendarService.GetApprovedAppointmentsAsync();
            AllRequests = [];
        }
        else
        {
            Employees = [];
            Appointments = [];
            AllRequests = [];
        }

        await LoadPendingRequestsAsync();
        SyncCalendarFocus();
    }

    // Bepaalt op welke week de kalender moet focussen.
    private void SyncCalendarFocus()
    {
        if (Appointments.Count == 0)
        {
            CurrentDate = DateTime.Today;
            return;
        }

        var targetDate = Appointments.Min(appointment => appointment.Start);
        if (SelectedAppointment is not null)
        {
            targetDate = SelectedAppointment.Start;
        }

        CurrentDate = new DateTime(targetDate.Year, targetDate.Month, targetDate.Day);
    }

    // Berekent de maandag van de week.
    private static DateTime GetStartOfWeek(DateTime date)
    {
        var diff = ((int)date.DayOfWeek + 6) % 7;
        return date.Date.AddDays(-diff);
    }

    // Geeft de juiste CSS-class terug voor een afspraak.
    private static string GetEntryClass(CalendarAppointment appointment) => appointment.TypeLabel switch
    {
        "Goedgekeurd" => "is-approved",
        "Afgekeurd" => "is-rejected",
        _ => "is-pending"
    };

    // Zet de status om naar een leesbaar label.
    private static string GetStatusLabel(VacationRequestStatus status) => status switch
    {
        VacationRequestStatus.Pending => "InBehandeling",
        VacationRequestStatus.Approved => "Goedgekeurd",
        VacationRequestStatus.Rejected => "Afgekeurd",
        _ => "Onbekend"
    };

    // Filtert openstaande aanvragen op naam.
    private bool MatchesPendingEmployeeSearch(VacationRequest request)
    {
        if (string.IsNullOrWhiteSpace(PendingEmployeeSearchTerm))
        {
            return true;
        }

        return request.EmployeeName.Contains(PendingEmployeeSearchTerm.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    // Filtert openstaande aanvragen op nieuwe of oude periode.
    private bool MatchesPendingPeriodFilter(VacationRequest request)
    {
        var today = DateOnly.FromDateTime(DateTime.Today);

        return PendingRequestPeriodFilter switch
        {
            ReviewRequestPeriod.New => request.EndDate >= today,
            ReviewRequestPeriod.Old => request.EndDate < today,
            _ => true
        };
    }

    private sealed record EmployeeCalendarRow(string Name, string Role);

    private enum ReviewRequestPeriod
    {
        All,
        New,
        Old
    }
}
