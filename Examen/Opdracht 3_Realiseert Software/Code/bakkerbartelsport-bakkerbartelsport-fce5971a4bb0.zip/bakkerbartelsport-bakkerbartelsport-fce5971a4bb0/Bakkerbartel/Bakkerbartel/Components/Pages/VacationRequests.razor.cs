using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bakkerbartel.Entities;
using Bakkerbartel.Services;
using Blazorise;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace Bakkerbartel.Components.Pages;

// Deze code achter de pagina regelt het overzicht en filteren van alle aanvragen.
public partial class VacationRequests : ComponentBase
{
    private List<VacationRequest> AllRequests { get; set; } = [];
    private string EmployeeSearchTerm { get; set; } = string.Empty;
    private string NoteDraft { get; set; } = string.Empty;
    private RequestPeriod RequestPeriodFilter { get; set; } = RequestPeriod.All;
    private RequestStatusFilter StatusFilter { get; set; } = RequestStatusFilter.All;
    private RequestSectionFilter SectionFilter { get; set; } = RequestSectionFilter.All;
    private VacationRequest? SelectedRequestForNote { get; set; }
    private VacationRequest? ApprovalWarningRequest { get; set; }
    private StaffingValidationResult? ApprovalWarningResult { get; set; }
    private bool IsNoteModalOpen { get; set; }
    private bool IsApprovalWarningModalOpen { get; set; }

    private IReadOnlyList<VacationRequest> FilteredRequests => AllRequests
        .Where(MatchesEmployeeSearch)
        .Where(MatchesPeriodFilter)
        .Where(MatchesStatusFilter)
        .ToList();

    private IReadOnlyList<VacationRequest> PendingRequests => FilteredRequests
        .Where(request => request.Status == VacationRequestStatus.Pending)
        .ToList();

    private IReadOnlyList<VacationRequest> ApprovedRequests => FilteredRequests
        .Where(request => request.Status == VacationRequestStatus.Approved)
        .ToList();

    private IReadOnlyList<VacationRequest> RejectedRequests => FilteredRequests
        .Where(request => request.Status == VacationRequestStatus.Rejected)
        .ToList();

    private IReadOnlyList<RequestSection> VisibleSections => SectionFilter switch
    {
        RequestSectionFilter.Pending => [new RequestSection("In behandeling", Color.Warning, PendingRequests)],
        RequestSectionFilter.Approved => [new RequestSection("Goedgekeurde aanvragen", Color.Success, ApprovedRequests)],
        RequestSectionFilter.Rejected => [new RequestSection("Afgekeurde aanvragen", Color.Danger, RejectedRequests)],
        _ =>
        [
            new RequestSection("In behandeling", Color.Warning, PendingRequests),
            new RequestSection("Goedgekeurde aanvragen", Color.Success, ApprovedRequests),
            new RequestSection("Afgekeurde aanvragen", Color.Danger, RejectedRequests)
        ]
    };

    // Laadt alle aanvragen als een beheerder de pagina opent.
    protected override async Task OnInitializedAsync()
    {
        if (UserContextService.IsAdmin)
        {
            await LoadRequestsAsync();
        }
    }

    // Geeft de juiste kleur terug voor de statusbadge.
    private static Color GetStatusColor(VacationRequestStatus status) => status switch
    {
        VacationRequestStatus.Pending => Color.Warning,
        VacationRequestStatus.Approved => Color.Success,
        VacationRequestStatus.Rejected => Color.Danger,
        _ => Color.Secondary
    };

    // Zet de status om naar een leesbaar label.
    private static string GetStatusLabel(VacationRequestStatus status) => status switch
    {
        VacationRequestStatus.Pending => "InBehandeling",
        VacationRequestStatus.Approved => "Goedgekeurd",
        VacationRequestStatus.Rejected => "Afgekeurd",
        _ => "Onbekend"
    };

    // Filtert aanvragen op naam van de werknemer.
    private bool MatchesEmployeeSearch(VacationRequest request)
    {
        if (string.IsNullOrWhiteSpace(EmployeeSearchTerm))
        {
            return true;
        }

        return request.EmployeeName.Contains(EmployeeSearchTerm.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    // Filtert aanvragen op nieuwe of oude periode.
    private bool MatchesPeriodFilter(VacationRequest request)
    {
        var today = DateOnly.FromDateTime(DateTime.Today);

        return RequestPeriodFilter switch
        {
            RequestPeriod.New => request.EndDate >= today,
            RequestPeriod.Old => request.EndDate < today,
            _ => true
        };
    }

    // Filtert aanvragen op status.
    private bool MatchesStatusFilter(VacationRequest request) => StatusFilter switch
    {
        RequestStatusFilter.Pending => request.Status == VacationRequestStatus.Pending,
        RequestStatusFilter.Approved => request.Status == VacationRequestStatus.Approved,
        RequestStatusFilter.Rejected => request.Status == VacationRequestStatus.Rejected,
        _ => true
    };

    // Laadt alle aanvragen opnieuw.
    private async Task LoadRequestsAsync()
    {
        AllRequests = (await VacationRequestService.GetAllAsync()).ToList();
    }

    // Opent het venster om een notitie te bewerken.
    private void OpenNoteModal(VacationRequest request)
    {
        SelectedRequestForNote = request;
        NoteDraft = request.AdminNote;
        IsNoteModalOpen = true;
    }

    // Sluit het notitievenster.
    private Task CloseNoteModal()
    {
        IsNoteModalOpen = false;
        SelectedRequestForNote = null;
        NoteDraft = string.Empty;
        return Task.CompletedTask;
    }

    // Slaat de beheernotitie van de geselecteerde aanvraag op.
    private async Task SaveNoteAsync()
    {
        if (SelectedRequestForNote is null)
        {
            return;
        }

        var selectedRequestId = SelectedRequestForNote.Id;
        var selectedEmployeeName = SelectedRequestForNote.EmployeeName;

        try
        {
            await VacationRequestService.SaveAdminNoteAsync(selectedRequestId, NoteDraft);
        }
        catch (UnauthorizedAccessException exception)
        {
            NotificationService.Notify(new NotificationMessage
            {
                Severity = NotificationSeverity.Warning,
                Summary = "Notitie niet opgeslagen",
                Detail = exception.Message,
                Duration = 3500
            });
            return;
        }

        await CloseNoteModal();
        NotificationService.Notify(new NotificationMessage
        {
            Severity = NotificationSeverity.Info,
            Summary = "Notitie opgeslagen",
            Detail = $"De notitie voor {selectedEmployeeName} is opgeslagen.",
            Duration = 2500
        });

        await LoadRequestsAsync();
    }

    // Keurt een aanvraag goed of wijst die af.
    private async Task ReviewAsync(VacationRequest request, VacationRequestStatus status, bool ignoreWarnings = false)
    {
        if (status == VacationRequestStatus.Approved && !ignoreWarnings)
        {
            var validationResult = await StaffingService.ValidateVacationRequestApprovalAsync(request);
            if (validationResult.HasWarnings)
            {
                ApprovalWarningRequest = request;
                ApprovalWarningResult = validationResult;
                IsApprovalWarningModalOpen = true;
                return;
            }
        }

        try
        {
            await VacationRequestService.ReviewAsync(request.Id, status, request.AdminNote, ignoreWarnings);
        }
        catch (Exception exception) when (exception is InvalidOperationException || exception is UnauthorizedAccessException)
        {
            NotificationService.Notify(new NotificationMessage
            {
                Severity = NotificationSeverity.Warning,
                Summary = "Beoordeling niet opgeslagen",
                Detail = exception.Message,
                Duration = 3500
            });
            return;
        }

        NotificationService.Notify(new NotificationMessage
        {
            Severity = status == VacationRequestStatus.Approved ? NotificationSeverity.Success : NotificationSeverity.Warning,
            Summary = status == VacationRequestStatus.Approved ? "Aanvraag goedgekeurd" : "Aanvraag afgewezen",
            Detail = $"{request.EmployeeName} is bijgewerkt naar {GetStatusLabel(status).ToLowerInvariant()}.",
            Duration = 3500
        });

        await LoadRequestsAsync();
        await CloseApprovalWarningModal();
    }

    // Sluit het waarschuwingvenster.
    private Task CloseApprovalWarningModal()
    {
        IsApprovalWarningModalOpen = false;
        ApprovalWarningRequest = null;
        ApprovalWarningResult = null;
        return Task.CompletedTask;
    }

    // Keurt toch goed nadat de beheerder de waarschuwing heeft gezien.
    private async Task ConfirmApprovalDespiteWarningsAsync()
    {
        if (ApprovalWarningRequest is null)
        {
            return;
        }

        await ReviewAsync(ApprovalWarningRequest, VacationRequestStatus.Approved, true);
    }

    private enum RequestPeriod
    {
        All,
        New,
        Old
    }

    private enum RequestStatusFilter
    {
        All,
        Pending,
        Approved,
        Rejected
    }

    private enum RequestSectionFilter
    {
        All,
        Pending,
        Approved,
        Rejected
    }

    private sealed record RequestSection(string Title, Color BadgeColor, IReadOnlyList<VacationRequest> Requests);
}
