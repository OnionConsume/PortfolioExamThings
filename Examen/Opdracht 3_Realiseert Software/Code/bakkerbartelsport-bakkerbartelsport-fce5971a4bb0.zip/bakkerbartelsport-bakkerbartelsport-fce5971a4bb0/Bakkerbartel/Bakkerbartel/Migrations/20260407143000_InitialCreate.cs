using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bakkerbartel.Migrations;

// Deze migratie maakt de eerste tabellen van de app aan.
public partial class InitialCreate : Migration
{
    // Deze methode voert de databasewijziging uit.
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "Employees",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                FullName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                Role = table.Column<int>(type: "int", nullable: false),
                Phone = table.Column<int>(type: "int", nullable: false),
                Email = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Employees", x => x.Id);
            });

        migrationBuilder.CreateTable(
            name: "VacationRequests",
            columns: table => new
            {
                Id = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                EmployeeId = table.Column<int>(type: "int", nullable: false),
                StartDate = table.Column<DateOnly>(type: "date", nullable: false),
                EndDate = table.Column<DateOnly>(type: "date", nullable: false),
                Reason = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                AdminNote = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false, defaultValue: ""),
                Status = table.Column<int>(type: "int", nullable: false),
                CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "SYSUTCDATETIME()")
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_VacationRequests", x => x.Id);
                table.ForeignKey(
                    name: "FK_VacationRequests_Employees_EmployeeId",
                    column: x => x.EmployeeId,
                    principalTable: "Employees",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateIndex(
            name: "IX_VacationRequests_EmployeeId",
            table: "VacationRequests",
            column: "EmployeeId");
    }

    // Deze methode draait de databasewijziging terug.
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(
            name: "VacationRequests");

        migrationBuilder.DropTable(
            name: "Employees");
    }
}
