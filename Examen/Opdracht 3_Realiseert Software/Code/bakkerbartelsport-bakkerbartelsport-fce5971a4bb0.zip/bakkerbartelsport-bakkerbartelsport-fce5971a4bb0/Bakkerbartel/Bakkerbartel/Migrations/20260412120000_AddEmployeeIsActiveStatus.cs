using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bakkerbartel.Migrations;

// Deze migratie voegt een actief/inactief-status toe aan werknemers.
public partial class AddEmployeeIsActiveStatus : Migration
{
    // Deze methode voegt de nieuwe kolom toe.
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<bool>(
            name: "IsActive",
            table: "Employees",
            type: "bit",
            nullable: false,
            defaultValue: true);
    }

    // Deze methode verwijdert de kolom weer bij een rollback.
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(
            name: "IsActive",
            table: "Employees");
    }
}
