namespace Bakkerbartel.Entities;

// Deze enum geeft aan welke rol een werknemer heeft.
public enum EmployeeRole
{
    Owner,
    Cashier,
    Baker,
    AllRound
}
