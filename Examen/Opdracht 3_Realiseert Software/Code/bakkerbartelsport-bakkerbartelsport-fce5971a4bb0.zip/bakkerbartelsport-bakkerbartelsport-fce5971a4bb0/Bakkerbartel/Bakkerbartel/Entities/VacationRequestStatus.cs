namespace Bakkerbartel.Entities;

// Deze enum bewaart de status van een vakantieaanvraag.
public enum VacationRequestStatus
{
    Pending,
    Approved,
    Rejected
}
