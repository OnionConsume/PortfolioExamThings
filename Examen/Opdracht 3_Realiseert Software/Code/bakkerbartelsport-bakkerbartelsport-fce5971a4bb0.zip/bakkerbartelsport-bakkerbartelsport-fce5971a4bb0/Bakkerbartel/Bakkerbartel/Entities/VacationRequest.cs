using System.ComponentModel.DataAnnotations.Schema;

namespace Bakkerbartel.Entities;

// Deze class stelt een vakantieaanvraag van een werknemer voor.
public sealed class VacationRequest
{
    public int Id { get; set; }
    // Dit is de koppeling naar de werknemer.
    public int EmployeeId { get; set; }
    public Employee? Employee { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
    public string Reason { get; set; } = string.Empty;
    public string AdminNote { get; set; } = string.Empty;
    public VacationRequestStatus Status { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    // Deze velden zijn alleen voor weergave en worden niet in de database opgeslagen.
    [NotMapped]
    public string EmployeeName => Employee?.FullName ?? string.Empty;

    [NotMapped]
    public string EmployeeRole => Employee?.Role.ToDisplayName() ?? string.Empty;

    // Hiermee berekenen we automatisch het totaal aantal vakantiedagen.
    public int TotalDays => EndDate.DayNumber - StartDate.DayNumber + 1;
}
