namespace Bakkerbartel.Entities;

// Deze class is een simpele weergave van een aanvraag in de kalender.
public sealed class CalendarAppointment
{
    public int Id { get; init; }
    public string Title { get; init; } = string.Empty;
    public string EmployeeName { get; init; } = string.Empty;
    public string EmployeeRole { get; init; } = string.Empty;
    public string TypeLabel { get; init; } = string.Empty;
    public DateTime Start { get; init; }
    public DateTime End { get; init; }
}
