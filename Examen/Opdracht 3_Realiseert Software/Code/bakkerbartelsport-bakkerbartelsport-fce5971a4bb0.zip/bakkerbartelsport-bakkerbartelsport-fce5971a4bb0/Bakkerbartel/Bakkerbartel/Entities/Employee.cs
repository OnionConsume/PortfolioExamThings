namespace Bakkerbartel.Entities;

// Deze class stelt een werknemer in de bakkerij voor.
public sealed class Employee
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public EmployeeRole Role { get; set; }
    public bool IsActive { get; set; } = true;
    public int Phone{ get; set; }
    public string Email { get; set; } = string.Empty;
    // Een werknemer kan meerdere vakantieaanvragen hebben.
    public ICollection<VacationRequest> VacationRequests { get; set; } = new List<VacationRequest>();
}
