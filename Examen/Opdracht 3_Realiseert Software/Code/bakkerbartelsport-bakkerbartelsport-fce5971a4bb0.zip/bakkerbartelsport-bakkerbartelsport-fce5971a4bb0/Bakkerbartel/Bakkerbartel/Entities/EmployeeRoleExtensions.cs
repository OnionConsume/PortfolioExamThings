namespace Bakkerbartel.Entities;

// Deze helper zet een rol om naar een nette Nederlandse naam.
public static class EmployeeRoleExtensions
{
    public static string ToDisplayName(this EmployeeRole role) => role switch
    {
        EmployeeRole.Owner => "Eigenaar",
        EmployeeRole.Cashier => "Kassa",
        EmployeeRole.Baker => "Bakker",
        EmployeeRole.AllRound => "Allround",
        _ => role.ToString()
    };
}
