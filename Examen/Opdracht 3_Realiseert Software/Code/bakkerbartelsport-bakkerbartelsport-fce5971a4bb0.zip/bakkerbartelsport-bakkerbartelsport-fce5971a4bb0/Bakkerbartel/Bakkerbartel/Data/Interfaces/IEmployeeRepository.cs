using Bakkerbartel.Entities;

namespace Bakkerbartel.Data.Interfaces;

// Deze interface bevat extra databaseacties voor werknemers.
public interface IEmployeeRepository : IBaseRepository<Employee>
{
    Task<IReadOnlyList<Employee>> GetAllOrderedAsync();
    Task<IReadOnlyList<Employee>> GetAllOrderedIncludingInactiveAsync();
    Task<IReadOnlyList<Employee>> GetNonOwnersAsync();
    Task<Employee?> GetByEmailAsync(string email);
    Task<bool> AnyByRoleAsync(EmployeeRole role);
}
