using Bakkerbartel.Data.Interfaces;
using Bakkerbartel.Entities;
using Microsoft.EntityFrameworkCore;

namespace Bakkerbartel.Data.Repositories;

// Deze repository bevat queries die speciaal voor werknemers zijn.
public sealed class EmployeeRepository : BaseRepository<Employee>, IEmployeeRepository
{
    private readonly ApplicationDbContext _context;

    public EmployeeRepository(ApplicationDbContext context) : base(context)
    {
        _context = context;
    }

    // Haalt alle actieve werknemers alfabetisch op.
    public async Task<IReadOnlyList<Employee>> GetAllOrderedAsync()
    {
        return await _context.Employees
            .Where(employee => employee.IsActive)
            .OrderBy(employee => employee.FullName)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt alle werknemers op, ook de inactieve.
    public async Task<IReadOnlyList<Employee>> GetAllOrderedIncludingInactiveAsync()
    {
        return await _context.Employees
            .OrderBy(employee => employee.FullName)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt alle actieve werknemers op behalve de eigenaar.
    public async Task<IReadOnlyList<Employee>> GetNonOwnersAsync()
    {
        return await _context.Employees
            .Where(employee => employee.Role != EmployeeRole.Owner && employee.IsActive)
            .AsNoTracking()
            .ToListAsync();
    }

    // Zoekt een werknemer op e-mailadres.
    public async Task<Employee?> GetByEmailAsync(string email)
    {
        return await _context.Employees
            .FirstOrDefaultAsync(employee => employee.Email == email);
    }

    // Zoekt een werknemer op telefoonnummer.
    public async Task<Employee?> GetByPhoneNumberAsync(string Number)
    {
        if (!int.TryParse(Number, out var phone))
        {
            return null;
        }

        return await _context.Employees
            .FirstOrDefaultAsync(employee => employee.Phone == phone);
    }

    // Controleert of er al een werknemer met deze rol bestaat.
    public async Task<bool> AnyByRoleAsync(EmployeeRole role)
    {
        return await _context.Employees.AnyAsync(employee => employee.Role == role);
    }
}
