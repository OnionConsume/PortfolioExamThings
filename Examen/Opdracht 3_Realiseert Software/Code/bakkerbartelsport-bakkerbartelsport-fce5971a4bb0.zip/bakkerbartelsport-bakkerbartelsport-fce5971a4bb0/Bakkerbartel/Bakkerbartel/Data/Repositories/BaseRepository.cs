using Bakkerbartel.Data.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Bakkerbartel.Data.Repositories;

// Deze class bevat de standaard CRUD-acties voor entiteiten.
public class BaseRepository<T>(ApplicationDbContext context) : IBaseRepository<T> where T : class
{
    private readonly DbSet<T> _dbSet = context.Set<T>();

    // Haalt alle records van dit type op.
    public async Task<List<T>> GetAllAsync()
    {
        return await _dbSet.ToListAsync();
    }

    // Haalt één record op via het id.
    public async Task<T?> GetByIdAsync(int id)
    {
        return await _dbSet.FindAsync(id);
    }

    // Voegt een nieuw record toe.
    public async Task<T> AddAsync(T entity)
    {
        _dbSet.Add(entity);
        await context.SaveChangesAsync();
        return entity;
    }

    // Werkt een bestaand record bij.
    public async Task<T> UpdateAsync(T entity)
    {
        _dbSet.Update(entity);
        await context.SaveChangesAsync();
        return entity;
    }

    // Verwijdert een record uit de database.
    public async Task DeleteAsync(T entity)
    {
        _dbSet.Remove(entity);
        await context.SaveChangesAsync();
    }
}
