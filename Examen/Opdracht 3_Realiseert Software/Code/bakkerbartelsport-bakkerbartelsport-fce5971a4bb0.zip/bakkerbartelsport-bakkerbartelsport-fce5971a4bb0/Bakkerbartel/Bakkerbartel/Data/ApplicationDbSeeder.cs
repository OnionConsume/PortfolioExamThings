using Bakkerbartel.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;

namespace Bakkerbartel.Data;

// Deze class vult de database met startdata en controleert oude databasen.
public static class ApplicationDbSeeder
{
    // Deze methode maakt de database klaar en zet voorbeeldgegevens erin.
    public static async Task SeedAsync(ApplicationDbContext context)
    {
        await EnsureLegacyDatabaseCompatibilityAsync(context);
        await context.Database.MigrateAsync();

        if (!await context.Employees.AnyAsync())
        {
            var seedEmployees = new List<Employee>
            {
                new() { FullName = "Bartel Bakker", Role = EmployeeRole.Owner, Phone = 610000001, Email = "bartel.bakker@bakkerbartel.nl" },
                new() { FullName = "Sanne de Vries", Role = EmployeeRole.AllRound, Phone = 610000002, Email = "sanne.devries@bakkerbartel.nl" },
                new() { FullName = "Milan Bakker", Role = EmployeeRole.Cashier, Phone = 610000003, Email = "milan.bakker@bakkerbartel.nl" },
                new() { FullName = "Noah Peters", Role = EmployeeRole.Baker, Phone = 610000004, Email = "noah.peters@bakkerbartel.nl" },
                new() { FullName = "Emma Jansen", Role = EmployeeRole.AllRound, Phone = 610000005, Email = "emma.jansen@bakkerbartel.nl" },
                new() { FullName = "Lisa Vermeer", Role = EmployeeRole.Cashier, Phone = 610000006, Email = "lisa.vermeer@bakkerbartel.nl" },
                new() { FullName = "Daan Smit", Role = EmployeeRole.Cashier, Phone = 610000007, Email = "daan.smit@bakkerbartel.nl" },
                new() { FullName = "Bram de Boer", Role = EmployeeRole.Baker, Phone = 610000008, Email = "bram.deboer@bakkerbartel.nl" },
                new() { FullName = "Tess van Dijk", Role = EmployeeRole.AllRound, Phone = 610000009, Email = "tess.vandijk@bakkerbartel.nl" }
            };

            await context.Employees.AddRangeAsync(seedEmployees);
            await context.SaveChangesAsync();
        }

        var ownerExists = await context.Employees.AnyAsync(employee => employee.Role == EmployeeRole.Owner);
        if (!ownerExists)
        {
            context.Employees.Add(new Employee
            {
                FullName = "Bartel Bakker",
                Role = EmployeeRole.Owner,
                Phone = 610000001,
                Email = "bartel.bakker@bakkerbartel.nl"
            });
            await context.SaveChangesAsync();
        }

        if (await context.VacationRequests.AnyAsync())
        {
            return;
        }

        var employees = await context.Employees
            .OrderBy(employee => employee.Id)
            .ToListAsync();

        var requests = new List<VacationRequest>
        {
            new()
            {
                EmployeeId = employees.First(employee => employee.FullName == "Sanne de Vries").Id,
                StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(9)),
                EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(11)),
                Reason = "Weekend weg",
                Status = VacationRequestStatus.Pending,
                CreatedAtUtc = DateTime.UtcNow.AddDays(-3)
            },
            new()
            {
                EmployeeId = employees.First(employee => employee.FullName == "Milan Bakker").Id,
                StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(14)),
                EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(16)),
                Reason = "Familiebezoek",
                Status = VacationRequestStatus.Pending,
                CreatedAtUtc = DateTime.UtcNow.AddDays(-2)
            },
            new()
            {
                EmployeeId = employees.First(employee => employee.FullName == "Noah Peters").Id,
                StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(18)),
                EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(19)),
                Reason = "Doktersafspraak en herstel",
                Status = VacationRequestStatus.Pending,
                CreatedAtUtc = DateTime.UtcNow.AddDays(-1)
            },
            new()
            {
                EmployeeId = employees.First(employee => employee.FullName == "Emma Jansen").Id,
                StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-8)),
                EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-6)),
                Reason = "Korte vakantie",
                AdminNote = "Goedgekeurd, bezetting blijft op orde.",
                Status = VacationRequestStatus.Approved,
                CreatedAtUtc = DateTime.UtcNow.AddDays(-20)
            },
            new()
            {
                EmployeeId = employees.First(employee => employee.FullName == "Milan Bakker").Id,
                StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-3)),
                EndDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-2)),
                Reason = "Prive afspraak",
                AdminNote = "Afgewezen wegens te weinig kassabezetting.",
                Status = VacationRequestStatus.Rejected,
                CreatedAtUtc = DateTime.UtcNow.AddDays(-10)
            }
        };

        await context.VacationRequests.AddRangeAsync(requests);
        await context.SaveChangesAsync();
    }

    // Deze methode controleert of een oudere database nog compatibel is.
    private static async Task EnsureLegacyDatabaseCompatibilityAsync(ApplicationDbContext context)
    {
        var employeesTableExists = await TableExistsAsync(context, "Employees");
        if (!employeesTableExists)
        {
            return;
        }

        var hasPhoneColumn = await ColumnExistsAsync(context, "Employees", "Phone");
        var hasEmailColumn = await ColumnExistsAsync(context, "Employees", "Email");
        var hasIsActiveColumn = await ColumnExistsAsync(context, "Employees", "IsActive");

        if (!hasPhoneColumn)
        {
            await context.Database.ExecuteSqlRawAsync("""
                ALTER TABLE dbo.Employees
                ADD Phone INT NOT NULL CONSTRAINT DF_Employees_Phone DEFAULT (0);
                """);
        }

        if (!hasEmailColumn)
        {
            await context.Database.ExecuteSqlRawAsync("""
                ALTER TABLE dbo.Employees
                ADD Email NVARCHAR(150) NOT NULL CONSTRAINT DF_Employees_Email DEFAULT (N'');
                """);
        }

        if (!hasIsActiveColumn)
        {
            await context.Database.ExecuteSqlRawAsync("""
                ALTER TABLE dbo.Employees
                ADD IsActive BIT NOT NULL CONSTRAINT DF_Employees_IsActive DEFAULT (1);
                """);
        }

        var historyTableExists = await TableExistsAsync(context, "__EFMigrationsHistory");
        if (!historyTableExists)
        {
            return;
        }

        var appliedMigrations = await context.Database
            .SqlQueryRaw<string>("SELECT MigrationId FROM dbo.__EFMigrationsHistory")
            .ToListAsync();

        if (appliedMigrations.Count == 0)
        {
            await context.Database.ExecuteSqlRawAsync("""
                INSERT INTO dbo.__EFMigrationsHistory (MigrationId, ProductVersion)
                VALUES ('20260407143000_InitialCreate', '10.0.5');
                """);
        }
    }

    // Deze methode kijkt of een tabel al bestaat.
    private static async Task<bool> TableExistsAsync(ApplicationDbContext context, string tableName)
    {
        var parameter = new SqlParameter("@tableName", tableName);

        var result = await context.Database
            .SqlQueryRaw<int>(
                "SELECT CASE WHEN EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = @tableName) THEN 1 ELSE 0 END AS Value",
                parameter)
            .SingleAsync();

        return result == 1;
    }

    // Deze methode kijkt of een kolom al bestaat.
    private static async Task<bool> ColumnExistsAsync(ApplicationDbContext context, string tableName, string columnName)
    {
        var tableParameter = new SqlParameter("@tableName", tableName);
        var columnParameter = new SqlParameter("@columnName", columnName);

        var result = await context.Database
            .SqlQueryRaw<int>(
                """
                SELECT CASE
                    WHEN EXISTS (
                        SELECT 1
                        FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_SCHEMA = 'dbo'
                          AND TABLE_NAME = @tableName
                          AND COLUMN_NAME = @columnName) THEN 1
                    ELSE 0
                END AS Value
                """,
                tableParameter,
                columnParameter)
            .SingleAsync();

        return result == 1;
    }
}
