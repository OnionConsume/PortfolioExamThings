using Bakkerbartel.Entities;

namespace Bakkerbartel.Data.Interfaces;

// Deze interface bevat extra databaseacties voor vakantieaanvragen.
public interface IVacationRequestRepository : IBaseRepository<VacationRequest>
{
    Task<IReadOnlyList<VacationRequest>> GetAllWithEmployeeAsync();
    Task<IReadOnlyList<VacationRequest>> GetPendingWithEmployeeAsync();
    Task<IReadOnlyList<VacationRequest>> GetForEmployeeAsync(int employeeId);
    Task<IReadOnlyList<VacationRequest>> GetVisibleForCalendarAsync(bool includeRejected = false);
    Task<IReadOnlyList<VacationRequest>> GetApprovedForCalendarAsync();
    Task<IReadOnlyList<VacationRequest>> GetEmployeeCalendarItemsAsync(int employeeId);
    Task<VacationRequest?> GetByIdWithEmployeeAsync(int id);
    Task<bool> HasOverlappingRequestAsync(int employeeId, DateOnly startDate, DateOnly endDate);
    Task<IReadOnlyList<VacationRequest>> GetApprovedOverlappingAsync(int excludedRequestId, DateOnly startDate, DateOnly endDate);
}
