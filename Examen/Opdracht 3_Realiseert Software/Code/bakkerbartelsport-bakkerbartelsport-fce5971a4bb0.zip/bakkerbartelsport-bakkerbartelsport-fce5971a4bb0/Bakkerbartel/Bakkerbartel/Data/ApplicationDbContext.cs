using Bakkerbartel.Entities;
using Microsoft.EntityFrameworkCore;

namespace Bakkerbartel.Data;

// Deze class regelt de koppeling tussen de app en de database.
public sealed class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<VacationRequest> VacationRequests => Set<VacationRequest>();

    // Hier stellen we de tabellen, velden en relaties in.
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Employee>(entity =>
        {
            entity.ToTable("Employees");
            entity.HasKey(employee => employee.Id);
            entity.Property(employee => employee.FullName).HasMaxLength(150).IsRequired();
            entity.Property(employee => employee.Role).HasConversion<int>().IsRequired();
            entity.Property(employee => employee.IsActive).HasDefaultValue(true).IsRequired();
            entity.Property(employee => employee.Phone).IsRequired();
            entity.Property(employee => employee.Email).HasMaxLength(150).IsRequired();
        });

        modelBuilder.Entity<VacationRequest>(entity =>
        {
            entity.ToTable("VacationRequests");
            entity.HasKey(request => request.Id);
            entity.Property(request => request.Reason).HasMaxLength(250).IsRequired();
            entity.Property(request => request.AdminNote).HasMaxLength(1000).HasDefaultValue(string.Empty);
            entity.Property(request => request.Status).HasConversion<int>().IsRequired();
            entity.Property(request => request.StartDate).HasColumnType("date");
            entity.Property(request => request.EndDate).HasColumnType("date");
            entity.Property(request => request.CreatedAtUtc).HasColumnType("datetime2").HasDefaultValueSql("SYSUTCDATETIME()");

            // Een aanvraag hoort bij precies één werknemer.
            entity.HasOne(request => request.Employee)
                .WithMany(employee => employee.VacationRequests)
                .HasForeignKey(request => request.EmployeeId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
