using Bakkerbartel.Data.Interfaces;
using Bakkerbartel.Entities;
using Microsoft.EntityFrameworkCore;

namespace Bakkerbartel.Data.Repositories;

// Deze repository bevat queries die speciaal voor vakantieaanvragen zijn.
public sealed class VacationRequestRepository : BaseRepository<VacationRequest>, IVacationRequestRepository
{
    private readonly ApplicationDbContext _context;

    public VacationRequestRepository(ApplicationDbContext context) : base(context)
    {
        _context = context;
    }

    // Haalt alle aanvragen op inclusief werknemergegevens.
    public async Task<IReadOnlyList<VacationRequest>> GetAllWithEmployeeAsync()
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .Where(request => request.Employee != null && request.Employee.IsActive)
            .OrderByDescending(request => request.StartDate)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt alleen openstaande aanvragen op.
    public async Task<IReadOnlyList<VacationRequest>> GetPendingWithEmployeeAsync()
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .Where(request => request.Status == VacationRequestStatus.Pending
                && request.Employee != null
                && request.Employee.IsActive)
            .OrderBy(request => request.StartDate)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt alle aanvragen van één werknemer op.
    public async Task<IReadOnlyList<VacationRequest>> GetForEmployeeAsync(int employeeId)
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .Where(request => request.EmployeeId == employeeId)
            .OrderByDescending(request => request.CreatedAtUtc)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt aanvragen op die in de kalender zichtbaar mogen zijn.
    public async Task<IReadOnlyList<VacationRequest>> GetVisibleForCalendarAsync(bool includeRejected = false)
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .Where(request => request.Employee != null
                && request.Employee.IsActive
                && (includeRejected || request.Status != VacationRequestStatus.Rejected))
            .OrderBy(request => request.StartDate)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt alleen goedgekeurde aanvragen voor de kalender op.
    public async Task<IReadOnlyList<VacationRequest>> GetApprovedForCalendarAsync()
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .Where(request => request.Status == VacationRequestStatus.Approved
                && request.Employee != null
                && request.Employee.IsActive)
            .OrderBy(request => request.StartDate)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt kalenderitems op voor één werknemer.
    public async Task<IReadOnlyList<VacationRequest>> GetEmployeeCalendarItemsAsync(int employeeId)
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .Where(request => request.EmployeeId == employeeId
                && request.Status != VacationRequestStatus.Rejected
                && request.Employee != null
                && request.Employee.IsActive)
            .OrderBy(request => request.StartDate)
            .AsNoTracking()
            .ToListAsync();
    }

    // Haalt één aanvraag op inclusief werknemergegevens.
    public async Task<VacationRequest?> GetByIdWithEmployeeAsync(int id)
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .FirstOrDefaultAsync(request => request.Id == id);
    }

    // Controleert of een werknemer al een overlappende aanvraag heeft.
    public async Task<bool> HasOverlappingRequestAsync(int employeeId, DateOnly startDate, DateOnly endDate)
    {
        return await _context.VacationRequests.AnyAsync(request =>
            request.EmployeeId == employeeId &&
            request.Status != VacationRequestStatus.Rejected &&
            request.StartDate <= endDate &&
            request.EndDate >= startDate);
    }

    // Haalt goedgekeurde overlappende aanvragen van andere werknemers op.
    public async Task<IReadOnlyList<VacationRequest>> GetApprovedOverlappingAsync(int excludedRequestId, DateOnly startDate, DateOnly endDate)
    {
        return await _context.VacationRequests
            .Include(request => request.Employee)
            .Where(request =>
                request.Id != excludedRequestId &&
                request.Employee != null &&
                request.Employee.IsActive &&
                request.Status == VacationRequestStatus.Approved &&
                request.StartDate <= endDate &&
                request.EndDate >= startDate)
            .AsNoTracking()
            .ToListAsync();
    }
}
