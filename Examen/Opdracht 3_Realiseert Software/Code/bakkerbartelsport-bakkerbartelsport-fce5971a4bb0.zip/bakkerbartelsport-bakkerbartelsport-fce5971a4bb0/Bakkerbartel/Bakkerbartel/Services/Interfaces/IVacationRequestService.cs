using Bakkerbartel.Entities;

namespace Bakkerbartel.Services.Interfaces;

// Deze interface beschrijft de service voor vakantieaanvragen.
public interface IVacationRequestService
{
    Task<IReadOnlyList<VacationRequest>> GetAllAsync();
    Task<IReadOnlyList<VacationRequest>> GetPendingAsync();
    Task<IReadOnlyList<VacationRequest>> GetForEmployeeAsync(int employeeId);
    Task<VacationRequest> CreateAsync(int employeeId, DateOnly startDate, DateOnly endDate, string reason);
    Task SaveAdminNoteAsync(int requestId, string adminNote);
    Task ReviewAsync(int requestId, VacationRequestStatus status, string adminNote, bool ignoreWarnings = false);
}
