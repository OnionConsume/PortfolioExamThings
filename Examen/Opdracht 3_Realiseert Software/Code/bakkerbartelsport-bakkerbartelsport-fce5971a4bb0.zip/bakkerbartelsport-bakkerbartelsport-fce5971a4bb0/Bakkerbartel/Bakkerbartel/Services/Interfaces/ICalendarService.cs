using Bakkerbartel.Entities;

namespace Bakkerbartel.Services.Interfaces;

// Deze interface beschrijft de service voor kalendergegevens.
public interface ICalendarService
{
    Task<IReadOnlyList<CalendarAppointment>> GetAppointmentsAsync(bool includeRejected = false);
    Task<IReadOnlyList<CalendarAppointment>> GetApprovedAppointmentsAsync();
    Task<IReadOnlyList<CalendarAppointment>> GetAppointmentsForEmployeeAsync(int employeeId);
}
