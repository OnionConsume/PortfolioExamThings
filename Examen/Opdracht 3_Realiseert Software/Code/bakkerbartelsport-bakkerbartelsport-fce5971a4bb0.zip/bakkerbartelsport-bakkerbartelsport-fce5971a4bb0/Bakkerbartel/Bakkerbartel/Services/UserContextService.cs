using Bakkerbartel.Data.Interfaces;
using Bakkerbartel.Entities;
using Bakkerbartel.Services.Interfaces;

namespace Bakkerbartel.Services;

// Deze service bewaart welke werknemer de app nu gebruikt.
public sealed class UserContextService(IEmployeeRepository employeeRepository) : IUserContextService
{
    private int? _currentEmployeeId;
    private EmployeeRole _currentRole = EmployeeRole.Owner;

    public int? CurrentEmployeeId => _currentEmployeeId;
    public EmployeeRole CurrentRole => _currentRole;
    public bool IsAdmin => _currentEmployeeId.HasValue && _currentRole == EmployeeRole.Owner;

    // Haalt alle actieve werknemers op voor de gebruikerskeuze.
    public async Task<IReadOnlyList<Employee>> GetEmployeesAsync()
    {
        return await employeeRepository.GetAllOrderedAsync();
    }

    // Zet de huidige werknemer en rol in de sessie.
    public async Task SetCurrentEmployeeAsync(int employeeId)
    {
        var employee = await employeeRepository.GetByIdAsync(employeeId);
        if (employee is null || !employee.IsActive)
        {
            _currentEmployeeId = null;
            _currentRole = EmployeeRole.Owner;
            return;
        }

        _currentEmployeeId = employee.Id;
        _currentRole = employee.Role;
    }
}
