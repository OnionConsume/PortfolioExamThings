namespace Bakkerbartel.Services;

// Dit resultaat geeft terug of een aanvraag veilig goedgekeurd kan worden.
public sealed class StaffingValidationResult
{
    // Geeft een positief resultaat terug zonder waarschuwingen.
    public static StaffingValidationResult Success() => new()
    {
        CanApprove = true
    };

    // Geeft een resultaat terug met waarschuwingen en probleemdagen.
    public static StaffingValidationResult Warning(
        string message,
        IReadOnlyList<StaffingValidationDay> days,
        IReadOnlyList<string> generalWarnings) => new()
    {
        CanApprove = true,
        HasWarnings = true,
        Message = message,
        ProblemDays = days,
        GeneralWarnings = generalWarnings
    };

    public bool CanApprove { get; init; }
    public bool HasWarnings { get; init; }
    public string Message { get; init; } = string.Empty;
    public IReadOnlyList<StaffingValidationDay> ProblemDays { get; init; } = [];
    public IReadOnlyList<string> GeneralWarnings { get; init; } = [];
}

// Deze class bewaart de bezettingsproblemen van één specifieke dag.
public sealed class StaffingValidationDay
{
    public required DateOnly Date { get; init; }
    public required int AvailableStaffCount { get; init; }
    public required int AvailableBakerCount { get; init; }
    public required int AvailableCashierCount { get; init; }
    public IReadOnlyList<string> Issues { get; init; } = [];
}
