using Bakkerbartel.Data.Interfaces;
using Bakkerbartel.Entities;
using Bakkerbartel.Services.Interfaces;

namespace Bakkerbartel.Services;

// Deze service bevat de businesslogica voor werknemersbeheer.
public sealed class EmployeeManagementService(
    IEmployeeRepository employeeRepository,
    IVacationRequestRepository vacationRequestRepository) : IEmployeeManagementService
{
    // Haalt alle werknemers op voor het beheer.
    public async Task<IReadOnlyList<Employee>> GetAllAsync()
    {
        return await employeeRepository.GetAllOrderedIncludingInactiveAsync();
    }

    // Voegt een nieuwe werknemer toe na controles.
    public async Task<Employee> AddAsync(Employee employee)
    {
        ValidateEmployee(employee);
        await EnsureUniqueEmailAsync(employee.Email, null);

        return await employeeRepository.AddAsync(employee);
    }

    // Werkt een bestaande werknemer bij.
    public async Task<Employee> UpdateAsync(Employee employee)
    {
        ValidateEmployee(employee);

        var existingEmployee = await employeeRepository.GetByIdAsync(employee.Id);
        if (existingEmployee is null)
        {
            throw new InvalidOperationException("Deze werknemer bestaat niet meer.");
        }

        await EnsureUniqueEmailAsync(employee.Email, employee.Id);

        existingEmployee.FullName = employee.FullName.Trim();
        existingEmployee.Role = employee.Role;
        existingEmployee.Phone = employee.Phone;
        existingEmployee.Email = employee.Email.Trim();

        return await employeeRepository.UpdateAsync(existingEmployee);
    }

    // Zet een werknemer actief of inactief.
    public async Task ToggleActiveStatusAsync(int employeeId)
    {
        var employee = await employeeRepository.GetByIdAsync(employeeId);
        if (employee is null)
        {
            throw new InvalidOperationException("Deze werknemer bestaat niet meer.");
        }

        if (employee.Role == EmployeeRole.Owner && employee.IsActive)
        {
            throw new InvalidOperationException("De beheerder kan niet op inactief gezet worden.");
        }

        employee.IsActive = !employee.IsActive;
        await employeeRepository.UpdateAsync(employee);
    }

    // Verwijdert een werknemer als dat veilig kan.
    public async Task DeleteAsync(int employeeId)
    {
        var employee = await employeeRepository.GetByIdAsync(employeeId);
        if (employee is null)
        {
            throw new InvalidOperationException("Deze werknemer bestaat niet meer.");
        }

        if (employee.Role == EmployeeRole.Owner)
        {
            throw new InvalidOperationException("De beheerder kan niet verwijderd worden.");
        }

        var requests = await vacationRequestRepository.GetForEmployeeAsync(employeeId);
        if (requests.Count > 0)
        {
            throw new InvalidOperationException("Deze werknemer heeft nog vakantieaanvragen en kan daarom niet verwijderd worden.");
        }

        await employeeRepository.DeleteAsync(employee);
    }

    // Controleert of het e-mailadres nog niet in gebruik is.
    private async Task EnsureUniqueEmailAsync(string email, int? currentEmployeeId)
    {
        var existingEmployee = await employeeRepository.GetByEmailAsync(email.Trim());
        if (existingEmployee is not null && existingEmployee.Id != currentEmployeeId)
        {
            throw new InvalidOperationException("Dit e-mailadres wordt al gebruikt door een andere werknemer.");
        }
    }

    // Controleert of de basisgegevens van een werknemer kloppen.
    private static void ValidateEmployee(Employee employee)
    {
        if (string.IsNullOrWhiteSpace(employee.FullName))
        {
            throw new InvalidOperationException("Naam is verplicht.");
        }

        if (employee.Phone < 0)
        {
            throw new InvalidOperationException("Telefoonnummer mag niet negatief zijn.");
        }

        if (string.IsNullOrWhiteSpace(employee.Email))
        {
            throw new InvalidOperationException("E-mail is verplicht.");
        }
    }
}
