using Bakkerbartel.Data.Interfaces;
using Bakkerbartel.Entities;
using Bakkerbartel.Services.Interfaces;

namespace Bakkerbartel.Services;

// Deze service controleert of goedkeuren nog past binnen de bezetting.
public sealed class StaffingService(
    IEmployeeRepository employeeRepository,
    IVacationRequestRepository vacationRequestRepository) : IStaffingService
{
    // Controleert per dag of er genoeg medewerkers overblijven.
    public async Task<StaffingValidationResult> ValidateVacationRequestApprovalAsync(VacationRequest request)
    {
        var staffMembers = await employeeRepository.GetNonOwnersAsync();

        var approvedAbsences = await vacationRequestRepository.GetApprovedOverlappingAsync(
            request.Id,
            request.StartDate,
            request.EndDate);

        var problemDays = new List<StaffingValidationDay>();
        var generalWarnings = new List<string>
        {
            "Zondag telt niet mee, omdat de bakkerij dan gesloten is.",
            "Werkdagen zonder vakantie worden behandeld als een standaarddienst van 8 uur.",
            "Per werkdag moeten minimaal 2 medewerkers beschikbaar blijven, waaronder minstens 1 bakker en 1 kassamedewerker.",
            "De 3-dagen-regel en 8-uursdienst worden nu alleen als algemene roosterregel getoond, omdat er nog geen echte dienstplanning per medewerker in de app zit."
        };

        for (var date = request.StartDate; date <= request.EndDate; date = date.AddDays(1))
        {
            if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                continue;
            }

            var absentEmployeeIds = approvedAbsences
                .Where(item => item.StartDate <= date && item.EndDate >= date)
                .Select(item => item.EmployeeId)
                .Append(request.EmployeeId)
                .Distinct()
                .ToHashSet();

            var availableStaff = staffMembers
                .Where(employee => !absentEmployeeIds.Contains(employee.Id))
                .ToList();

            var availableBakerCount = availableStaff.Count(CanWorkAsBaker);
            var availableCashierCount = availableStaff.Count(CanWorkAsCashier);
            var issues = new List<string>();

            if (availableStaff.Count < 2)
            {
                issues.Add($"Er blijven maar {availableStaff.Count} medewerker(s) over.");
            }

            if (availableBakerCount < 1)
            {
                issues.Add("Er is geen bakker beschikbaar.");
            }

            if (availableCashierCount < 1)
            {
                issues.Add("Er is geen kassamedewerker beschikbaar.");
            }

            if (issues.Count > 0)
            {
                problemDays.Add(new StaffingValidationDay
                {
                    Date = date,
                    AvailableStaffCount = availableStaff.Count,
                    AvailableBakerCount = availableBakerCount,
                    AvailableCashierCount = availableCashierCount,
                    Issues = issues
                });
            }
        }

        if (problemDays.Count == 0)
        {
            return StaffingValidationResult.Success();
        }

        var firstProblemDay = problemDays.FirstOrDefault();
        var message = firstProblemDay is not null
            ? $"Waarschuwing: op {firstProblemDay.Date:dd-MM-yyyy} komt de bezetting onder de gewenste regels."
            : "Waarschuwing: deze aanvraag botst met de huidige roosterregels.";

        return StaffingValidationResult.Warning(message, problemDays, generalWarnings.Distinct().ToList());
    }

    // Bepaalt of iemand bakkerwerk kan doen.
    private static bool CanWorkAsBaker(Employee employee) =>
        employee.Role is EmployeeRole.Baker or EmployeeRole.AllRound;

    // Bepaalt of iemand kassawerk kan doen.
    private static bool CanWorkAsCashier(Employee employee) =>
        employee.Role is EmployeeRole.Cashier or EmployeeRole.AllRound;
}
