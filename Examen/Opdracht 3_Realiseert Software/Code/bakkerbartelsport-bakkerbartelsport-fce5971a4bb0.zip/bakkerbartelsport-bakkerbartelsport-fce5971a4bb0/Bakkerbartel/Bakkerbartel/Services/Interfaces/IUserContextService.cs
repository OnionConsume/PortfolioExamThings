using Bakkerbartel.Entities;

namespace Bakkerbartel.Services.Interfaces;

// Deze interface bewaart welke werknemer nu is ingelogd.
public interface IUserContextService
{
    int? CurrentEmployeeId { get; }
    EmployeeRole CurrentRole { get; }
    bool IsAdmin { get; }
    Task<IReadOnlyList<Employee>> GetEmployeesAsync();
    Task SetCurrentEmployeeAsync(int employeeId);
}
