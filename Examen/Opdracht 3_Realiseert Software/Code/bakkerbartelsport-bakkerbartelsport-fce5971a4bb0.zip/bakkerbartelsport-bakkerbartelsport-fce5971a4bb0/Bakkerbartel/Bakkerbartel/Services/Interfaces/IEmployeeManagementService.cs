using Bakkerbartel.Entities;

namespace Bakkerbartel.Services.Interfaces;

// Deze interface beschrijft de service voor werknemersbeheer.
public interface IEmployeeManagementService
{
    Task<IReadOnlyList<Employee>> GetAllAsync();
    Task<Employee> AddAsync(Employee employee);
    Task<Employee> UpdateAsync(Employee employee);
    Task ToggleActiveStatusAsync(int employeeId);
    Task DeleteAsync(int employeeId);
}
