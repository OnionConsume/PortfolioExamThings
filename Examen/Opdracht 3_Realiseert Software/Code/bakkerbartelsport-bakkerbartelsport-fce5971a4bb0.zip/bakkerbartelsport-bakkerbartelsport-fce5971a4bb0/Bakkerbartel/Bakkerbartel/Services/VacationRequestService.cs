using Bakkerbartel.Data.Interfaces;
using Bakkerbartel.Entities;
using Bakkerbartel.Services.Interfaces;

namespace Bakkerbartel.Services;

// Deze service bevat alle businesslogica rond vakantieaanvragen.
public sealed class VacationRequestService(
    IVacationRequestRepository vacationRequestRepository,
    IEmployeeRepository employeeRepository,
    IUserContextService userContextService,
    IStaffingService staffingService) : IVacationRequestService
{
    // Haalt alle aanvragen op voor de beheerder.
    public async Task<IReadOnlyList<VacationRequest>> GetAllAsync()
    {
        EnsureAdmin();

        return await vacationRequestRepository.GetAllWithEmployeeAsync();
    }

    // Haalt alleen openstaande aanvragen op voor de beheerder.
    public async Task<IReadOnlyList<VacationRequest>> GetPendingAsync()
    {
        EnsureAdmin();

        return await vacationRequestRepository.GetPendingWithEmployeeAsync();
    }

    // Haalt de aanvragen van één werknemer op.
    public async Task<IReadOnlyList<VacationRequest>> GetForEmployeeAsync(int employeeId)
    {
        EnsureEmployeeContext(employeeId);
        await EnsureEmployeeIsActiveAsync(employeeId);

        return await vacationRequestRepository.GetForEmployeeAsync(employeeId);
    }

    // Maakt een nieuwe aanvraag aan na controles op data en overlap.
    public async Task<VacationRequest> CreateAsync(int employeeId, DateOnly startDate, DateOnly endDate, string reason)
    {
        EnsureEmployeeContext(employeeId);
        await EnsureEmployeeIsActiveAsync(employeeId);

        if (startDate < DateOnly.FromDateTime(DateTime.Today))
        {
            throw new InvalidOperationException("De startdatum mag niet in het verleden liggen.");
        }

        if (endDate < startDate)
        {
            throw new InvalidOperationException("Einddatum mag niet voor de startdatum liggen.");
        }

        if (string.IsNullOrWhiteSpace(reason))
        {
            throw new InvalidOperationException("Een reden is verplicht voor een aanvraag.");
        }

        var hasOverlap = await vacationRequestRepository.HasOverlappingRequestAsync(employeeId, startDate, endDate);

        if (hasOverlap)
        {
            throw new InvalidOperationException("Er bestaat al een lopende of goedgekeurde aanvraag in deze periode.");
        }

        var request = new VacationRequest
        {
            EmployeeId = employeeId,
            StartDate = startDate,
            EndDate = endDate,
            Reason = reason.Trim(),
            Status = VacationRequestStatus.Pending,
            CreatedAtUtc = DateTime.UtcNow
        };

        await vacationRequestRepository.AddAsync(request);

        return await vacationRequestRepository.GetByIdWithEmployeeAsync(request.Id)
            ?? throw new InvalidOperationException("De nieuwe vakantieaanvraag kon niet opnieuw worden opgehaald.");
    }

    // Slaat een notitie van de beheerder op.
    public async Task SaveAdminNoteAsync(int requestId, string adminNote)
    {
        EnsureAdmin();

        var request = await vacationRequestRepository.GetByIdWithEmployeeAsync(requestId);
        if (request is null)
        {
            return;
        }

        if (request.Employee is null || !request.Employee.IsActive)
        {
            throw new InvalidOperationException("Deze werknemer is inactief en komt tijdelijk niet meer mee in het overzicht.");
        }

        request.AdminNote = (adminNote ?? string.Empty).Trim();
        await vacationRequestRepository.UpdateAsync(request);
    }

    // Beoordeelt een aanvraag en controleert eventueel de bezetting.
    public async Task ReviewAsync(int requestId, VacationRequestStatus status, string adminNote, bool ignoreWarnings = false)
    {
        EnsureAdmin();

        if (status == VacationRequestStatus.Pending)
        {
            throw new InvalidOperationException("Een beoordeling moet goedgekeurd of afgekeurd zijn.");
        }

        var request = await vacationRequestRepository.GetByIdWithEmployeeAsync(requestId);
        if (request is null)
        {
            return;
        }

        if (request.Employee is null || !request.Employee.IsActive)
        {
            throw new InvalidOperationException("Deze werknemer is inactief en deze aanvraag kan nu niet beoordeeld worden.");
        }

        if (status == VacationRequestStatus.Approved)
        {
            var staffingResult = await staffingService.ValidateVacationRequestApprovalAsync(request);
            if (staffingResult.HasWarnings && !ignoreWarnings)
            {
                throw new InvalidOperationException(staffingResult.Message);
            }
        }

        request.Status = status;
        request.AdminNote = (adminNote ?? string.Empty).Trim();

        await vacationRequestRepository.UpdateAsync(request);
    }

    // Controleert of de huidige gebruiker beheerder is.
    private void EnsureAdmin()
    {
        if (!userContextService.IsAdmin)
        {
            throw new UnauthorizedAccessException("Alleen een beheerder mag deze actie uitvoeren.");
        }
    }

    // Controleert of een werknemer alleen zijn eigen aanvragen opent.
    private void EnsureEmployeeContext(int employeeId)
    {
        if (userContextService.CurrentEmployeeId != employeeId || userContextService.IsAdmin)
        {
            throw new UnauthorizedAccessException("Werknemers mogen alleen eigen aanvragen beheren.");
        }
    }

    // Controleert of de werknemer nog actief is.
    private async Task EnsureEmployeeIsActiveAsync(int employeeId)
    {
        var employee = await employeeRepository.GetByIdAsync(employeeId);
        if (employee is null || !employee.IsActive)
        {
            throw new UnauthorizedAccessException("Deze werknemer is tijdelijk inactief en kan nu niets aanvragen of openen.");
        }
    }
}
