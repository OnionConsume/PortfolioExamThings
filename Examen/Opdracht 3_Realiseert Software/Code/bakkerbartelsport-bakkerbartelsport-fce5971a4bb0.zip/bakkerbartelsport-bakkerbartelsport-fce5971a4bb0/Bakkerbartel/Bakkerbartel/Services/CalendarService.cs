using Bakkerbartel.Data.Interfaces;
using Bakkerbartel.Entities;
using Bakkerbartel.Services.Interfaces;

namespace Bakkerbartel.Services;

// Deze service zet vakantieaanvragen om naar kalenderitems.
public sealed class CalendarService(IVacationRequestRepository vacationRequestRepository) : ICalendarService
{
    // Haalt alle zichtbare afspraken voor de kalender op.
    public async Task<IReadOnlyList<CalendarAppointment>> GetAppointmentsAsync(bool includeRejected = false)
    {
        var requests = await vacationRequestRepository.GetVisibleForCalendarAsync(includeRejected);

        return MapAppointments(requests);
    }

    // Haalt alleen goedgekeurde afspraken voor de kalender op.
    public async Task<IReadOnlyList<CalendarAppointment>> GetApprovedAppointmentsAsync()
    {
        var requests = await vacationRequestRepository.GetApprovedForCalendarAsync();

        return MapAppointments(requests);
    }

    // Haalt kalenderafspraken voor één werknemer op.
    public async Task<IReadOnlyList<CalendarAppointment>> GetAppointmentsForEmployeeAsync(int employeeId)
    {
        var requests = await vacationRequestRepository.GetEmployeeCalendarItemsAsync(employeeId);

        return MapAppointments(requests);
    }

    // Zet databaseaanvragen om naar simpele kalenderobjecten.
    private static IReadOnlyList<CalendarAppointment> MapAppointments(IReadOnlyCollection<VacationRequest> requests)
    {
        return requests.Select(request => new CalendarAppointment
        {
            Id = request.Id,
            Title = request.Status switch
            {
                VacationRequestStatus.Pending => "Vakantieaanvraag",
                VacationRequestStatus.Approved => "Goedgekeurde vakantie",
                VacationRequestStatus.Rejected => "Afgekeurde aanvraag",
                _ => "Aanvraag"
            },
            EmployeeName = request.EmployeeName,
            EmployeeRole = request.EmployeeRole,
            TypeLabel = request.Status switch
            {
                VacationRequestStatus.Pending => "InBehandeling",
                VacationRequestStatus.Approved => "Goedgekeurd",
                VacationRequestStatus.Rejected => "Afgekeurd",
                _ => "Onbekend"
            },
            Start = request.StartDate.ToDateTime(TimeOnly.MinValue),
            End = request.EndDate.ToDateTime(new TimeOnly(23, 59))
        }).ToList();
    }
}
