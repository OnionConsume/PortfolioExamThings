using Bakkerbartel.Entities;
using Bakkerbartel.Services;

namespace Bakkerbartel.Services.Interfaces;

// Deze interface beschrijft de controle van de bezetting.
public interface IStaffingService
{
    Task<StaffingValidationResult> ValidateVacationRequestApprovalAsync(VacationRequest request);
}
